package com.customer.assessment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.customer.assessment.bean.SoftwareService;
import com.customer.assessment.serviceimpl.ServiceServiceImpl;
import com.customer.assessment.util.CustOnboardingUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Validated
@Api(tags = "Service APIs")
@RestController
@RequestMapping(value = "/service")
public class ServicesController {
	
	@Autowired
	private ServiceServiceImpl customerServiceServiceImpl;
	
	@PostMapping(value="/save")
	@ApiOperation(value = "Create new Software service", notes = "Create new Software service")
	public ResponseEntity<?> save(@RequestBody SoftwareService softwareService) throws Exception {
		SoftwareService serviceResponse = customerServiceServiceImpl.saveCustomerService(softwareService);
		if(serviceResponse != null) {
			return new ResponseEntity<>(serviceResponse, HttpStatus.CREATED);
		}
		return new ResponseEntity<>("Unable to create Service", HttpStatus.BAD_REQUEST);
	}

	@PostMapping(value="/update")
	@ApiOperation(value = "Update Software service", notes = "Updaate Software service")
	public ResponseEntity<?> update(@RequestBody SoftwareService softwareService) throws Exception {
		SoftwareService serviceResponse = customerServiceServiceImpl.updateCustomerService(softwareService);
		if(serviceResponse != null) {
			return new ResponseEntity<>(serviceResponse, HttpStatus.CREATED);
		}
		return new ResponseEntity<>("Unable to create Service", HttpStatus.BAD_REQUEST);
	}

	@GetMapping(value="/findAll")
	@ApiOperation(value = "Get all Services", notes = "Get all Services")
	public ResponseEntity<?> fetchAll() throws Exception {
		List<SoftwareService> serviceResponse = customerServiceServiceImpl.findAll();
		if(serviceResponse != null || !serviceResponse.isEmpty()) {
			return new ResponseEntity<>(serviceResponse, HttpStatus.OK);
		}
		return new ResponseEntity<>("Unable to create Service", HttpStatus.NO_CONTENT);
	}
}
