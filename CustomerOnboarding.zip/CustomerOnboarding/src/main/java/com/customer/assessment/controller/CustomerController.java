package com.customer.assessment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.customer.assessment.bean.CustomerPlan;
import com.customer.assessment.dto.CustomerDto;
import com.customer.assessment.dto.CustomerSubscriptionsDto;
import com.customer.assessment.dto.SubscriptionDTO;
import com.customer.assessment.serviceimpl.CustomerServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Validated
@Api(tags = "Customer Onboarding Portal API")
@RestController
@RequestMapping(value = "/customer")
public class CustomerController {
	
	@Autowired
	private CustomerServiceImpl customerServiceImpl;
	
	@PostMapping(value="/save")
	@ApiOperation(value = "Create Customer", notes = "Create customer")
	public ResponseEntity<?> save(@RequestBody CustomerDto customer) throws Exception {
		CustomerDto customerDto = customerServiceImpl.createCustomer(customer);
		if(customerDto != null) {
			return new ResponseEntity<>(customerDto, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>("Unable to create Customer", HttpStatus.BAD_REQUEST);
		}
		
	}

	@PutMapping(value="/update")
	@ApiOperation(value = "Create Customer", notes = "Create customer")
	public ResponseEntity<?> update(@RequestBody CustomerDto customer) throws Exception {
		CustomerDto customerDto = customerServiceImpl.updateCustomer(customer);
		if(customerDto != null) {
			return new ResponseEntity<>(customerDto, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>("Unable to create Customer", HttpStatus.BAD_REQUEST);
		}
		
	}

	@GetMapping(value="/getById/{id}")
	@ApiOperation(value = "Get Customer By id", notes = "Get Customer By id")
	public ResponseEntity<?> fetch(@RequestParam("id") String id) throws Exception {
		CustomerDto customerDto = customerServiceImpl.findCustomer(id);
		if(customerDto != null) {
			return new ResponseEntity<>(customerDto, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>("Customer does not exist.", HttpStatus.NO_CONTENT);
		}
	}
	
	@PostMapping(value="/subscribeToServices")
	@ApiOperation(value = "Chose plans to Customer", notes = "Chose plans to Customer")
	public ResponseEntity<?> savePlan(@RequestBody SubscriptionDTO subscription) throws Exception {
		List<CustomerPlan> customerDto = customerServiceImpl.subscribe(subscription);
		if(customerDto != null) {
			return new ResponseEntity<>(customerDto, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>("Unable to subscribe customer", HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(value="/fetchAll")
	@ApiOperation(value = "Find all Customers", notes = "Find all customers")
	public ResponseEntity<?> getAll() throws Exception {
		List<CustomerDto> customerDto = customerServiceImpl.findAll();
		if(customerDto != null) {
			return new ResponseEntity<>(customerDto, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>("Customer does not exist.", HttpStatus.NO_CONTENT);
		}		
	}
	
	@GetMapping(value="/getCustomerSubscriptionsById/{id}")
	@ApiOperation(value = "Get Customer and Subscription details By customer id", notes = "Get Customer and Subscription details By customer id")
	public ResponseEntity<?> fetchAllDetails(@RequestParam("id") String id) throws Exception {
		CustomerSubscriptionsDto customerDto = customerServiceImpl.findCustomerDetails(id);
		if(customerDto != null) {
			return new ResponseEntity<>(customerDto, HttpStatus.CREATED);
		} else {
			return new ResponseEntity<>("Customer does not exist.", HttpStatus.NO_CONTENT);
		}
	}
}
