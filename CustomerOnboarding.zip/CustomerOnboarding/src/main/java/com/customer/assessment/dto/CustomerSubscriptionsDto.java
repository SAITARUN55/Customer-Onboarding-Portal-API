package com.customer.assessment.dto;

import java.util.HashMap;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CustomerSubscriptionsDto {
	private String customerID;
	private String customerName;
	private HashMap<String, String> serviceName;
}
