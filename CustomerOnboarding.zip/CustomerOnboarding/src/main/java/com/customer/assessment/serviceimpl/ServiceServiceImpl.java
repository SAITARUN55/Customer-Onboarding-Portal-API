package com.customer.assessment.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customer.assessment.bean.SoftwareService;
import com.customer.assessment.repository.ServiceRepository;
import com.customer.assessment.util.CustOnboardingUtil;

@Service
public class ServiceServiceImpl {

	@Autowired
	private ServiceRepository serviceRepository;

	public com.customer.assessment.bean.SoftwareService saveCustomerService(SoftwareService softwareService) {
		softwareService.setId(CustOnboardingUtil.getShortGUID());
		softwareService.getPlanList().forEach(plan -> {
			plan.setId(CustOnboardingUtil.getShortGUID());
			plan.setServiceId(softwareService.getId());
		});
		SoftwareService serviceResponse = serviceRepository.save(softwareService);
		if (serviceResponse != null) {
			return serviceResponse;
		}
		return null;
	}

	public List<SoftwareService> findAll() {
		Iterable<SoftwareService> serviceResponse = serviceRepository.findAll();
		if(serviceResponse != null) {
			List<SoftwareService> result = new ArrayList<SoftwareService>();
			serviceResponse.forEach(result::add);
			return result;
		}
		return null;
	}

	public SoftwareService updateCustomerService(SoftwareService softwareService) {
		if(softwareService.getId() == null) {
			return null;
		}
		SoftwareService serviceResponse = serviceRepository.save(softwareService);
		if (serviceResponse != null) {
			return serviceResponse;
		}
		return null;
	}
}

// security
