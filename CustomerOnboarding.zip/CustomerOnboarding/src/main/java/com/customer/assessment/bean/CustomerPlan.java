package com.customer.assessment.bean;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CustomerPlan {
	
	@Id
	private String id;
	private String custId;
	private String planId;
	private LocalDate dateActivated;
	private boolean isActive;

}
