package com.customer.assessment.serviceimpl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.customer.assessment.bean.Customer;
import com.customer.assessment.bean.CustomerPlan;
import com.customer.assessment.bean.Plan;
import com.customer.assessment.bean.SoftwareService;
import com.customer.assessment.dto.CustomerDto;
import com.customer.assessment.dto.CustomerSubscriptionsDto;
import com.customer.assessment.dto.SubscriptionDTO;
import com.customer.assessment.repository.CustomerPlanRepository;
import com.customer.assessment.repository.CustomerRepository;
import com.customer.assessment.repository.PlanRepository;
import com.customer.assessment.repository.ServiceRepository;
import com.customer.assessment.util.CustOnboardingUtil;

@Service
public class CustomerServiceImpl {

	@Autowired
	private CustomerRepository customerRepository;

	@Autowired
	private CustomerPlanRepository customerPlanRepository;

	@Autowired
	private PlanRepository planRepository;
	
	@Autowired
	private ServiceRepository serviceRepository;
	
	public CustomerDto createCustomer(CustomerDto customerDto) {
		Customer customer = new Customer(CustOnboardingUtil.getShortGUID(),customerDto.getName(), customerDto.getEmail(), customerDto.getAddress(), customerDto.getOnboardingDate());
		if(isValid(customer)) {
			customer = customerRepository.save(customer);
			customerDto = new CustomerDto(customer.getId(), customer.getName(), customer.getEmail(), customer.getAddress(), customer.getOnboardingDate());
			return customerDto;
		}
		return null;
	}

	private boolean isValid(Customer customer) {
		if(customer.getOnboardingDate().isBefore(LocalDate.now())) {
			return false;
		}
		return true;
	}

	public CustomerDto updateCustomer(CustomerDto customerDto) {
		Customer customer = new Customer(customerDto.getId(),customerDto.getName(), customerDto.getEmail(), customerDto.getAddress(), customerDto.getOnboardingDate());
		customer = customerRepository.save(customer);
		customerDto = new CustomerDto(customer.getId(), customer.getName(), customer.getEmail(), customer.getAddress(), customer.getOnboardingDate());
		return customerDto;
	}

	public CustomerDto findCustomer(String id) {
		Optional<Customer> customer = customerRepository.findById(id);
		if(customer.isPresent()) {
			CustomerDto customerDto = new CustomerDto(customer.get().getId(), customer.get().getName(), customer.get().getEmail(), customer.get().getAddress(), customer.get().getOnboardingDate());
			return customerDto;
		}		
		return null;
	}

	public List<CustomerPlan> subscribe(SubscriptionDTO subscription) {
		List<CustomerPlan> planList = new ArrayList<>();
		Optional<Customer> customer = customerRepository.findById(subscription.getCustomerId());
		if(customer.isPresent()) {
			subscription.getPlanIds().forEach(planId -> {
				CustomerPlan custPlan = new CustomerPlan(CustOnboardingUtil.getShortGUID(),subscription.getCustomerId(), 
						planId, LocalDate.now(), subscription.isActive());
				custPlan = customerPlanRepository.save(custPlan);
				planList.add(custPlan);
			});
			return planList;
		}	
		return null;				
	}

	public List<CustomerDto> findAll() {
		Iterable<Customer> customerList = customerRepository.findAll();
		List<CustomerDto> customerDtoList = new ArrayList<>(); 
		customerList.forEach(customer -> {
			CustomerDto customerDto = new CustomerDto(customer.getId(), customer.getName(), customer.getEmail(), customer.getAddress(), customer.getOnboardingDate());
			customerDtoList.add(customerDto);
		});
		return customerDtoList;
	}

	public CustomerSubscriptionsDto findCustomerDetails(String id) {
		CustomerSubscriptionsDto response = new CustomerSubscriptionsDto();
		Optional<Customer> customer = customerRepository.findById(id);
		response.setCustomerID(id);
		response.setCustomerName(customer.get().getName());
		List<CustomerPlan> planList = customerPlanRepository.findByCustId(id);
		HashMap<String,String> planServiceMap = new HashMap<>();
		planList.forEach(plan -> {
			Optional<Plan> planResponse = planRepository.findById(plan.getPlanId());
			if(planResponse.isPresent()) {
				Optional<SoftwareService> softwareService = serviceRepository.findById(planResponse.get().getServiceId());
				if(softwareService.isPresent()) {
					planServiceMap.put(planResponse.get().getName(), softwareService.get().getName());
				}
			}
		});
		response.setServiceName(planServiceMap);
		return response;
	}	
}