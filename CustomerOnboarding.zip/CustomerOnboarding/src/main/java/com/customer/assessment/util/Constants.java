package com.customer.assessment.util;

public class Constants {
	
	public static final String URL = "https://api.open-meteo.com/v1/forecast?latitude=%s&longitude=%s&hourly=precipitation";

}
