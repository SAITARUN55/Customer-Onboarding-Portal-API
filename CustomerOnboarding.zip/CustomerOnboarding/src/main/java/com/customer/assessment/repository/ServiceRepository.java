package com.customer.assessment.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.customer.assessment.bean.SoftwareService;

@Repository
public interface ServiceRepository extends CrudRepository<SoftwareService, String>{
	
}
