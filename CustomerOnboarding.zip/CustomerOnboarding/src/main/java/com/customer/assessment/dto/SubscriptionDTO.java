package com.customer.assessment.dto;

import java.time.LocalDate;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class SubscriptionDTO {
	private String customerId;
	private List<String> planIds;
	private LocalDate activationDate;
	private boolean isActive;

}
