package com.customer.assessment.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.customer.assessment.bean.CustomerPlan;

@Repository
public interface CustomerPlanRepository extends CrudRepository<CustomerPlan, String>{
	
	List<CustomerPlan> findByCustId(String custId);
	
}
