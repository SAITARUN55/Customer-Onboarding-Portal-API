package com.customer.assessment.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.customer.assessment.bean.Plan;

@Repository
public interface PlanRepository extends CrudRepository<Plan, String>{
	
}
